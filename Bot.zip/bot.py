import telebot as tb
from telebot import types
import requests as rq
import json
import time
from PIL import Image
from io import BytesIO

tags = {'1':'#TechnoCom',
        '2':'#ITfest_2022',
        '3':'#IASF2022',
        '4':'#ФестивальОКК',
        '5':'#Нейрофест',
        '6':'#НевидимыйМир',
        '7':'#КонкурсНИР',
        '8':'#VRARFest3D'}

with open('data.json', 'r') as rdata:
    if rdata.read() == '':
        with open('data.json', 'w') as wdata:
            wdata.write('{}')

base_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
base_markup.add(types.KeyboardButton('Новые посты на которые вы подписаны 🗞'), types.KeyboardButton('Последние посты 📌'))
base_markup.add(types.KeyboardButton('Подписаться на события ❤️'), types.KeyboardButton('Подписки 📝'))
base_markup.add(types.KeyboardButton('Контактные данные 📨'))

token = '3b3bd1566193896608b9790d3e066e50e848604e95048ea32700c6bd8122a00bbc24f4f6bd209c9e176da'

#авто-форматирование для удобства
def vk_api(method):
    return 'https://api.vk.com/method/' + method

#поиск последней записи по хештегу
def news_found(tag, count, start_time=None, end_time=None):
    time_now = time.time()
    if start_time == None:
        start_time = time_now - 31556926
    if end_time == None:
        end_time = time_now
    params = {'q': tag, 'count': count, 'access_token': token, 'extended': 0, 'v': '5.131', 'start_time':start_time, 'end_time':end_time}
    output = rq.request(url=vk_api('newsfeed.search'), params=params, method='GET').json()
    print(tag, count, output)
    return output['response']['items']

bot = tb.TeleBot('5235874030:AAEnWFy8nUeEC5xXpnDoPtcLbM2NF04wTP8')


@bot.message_handler(commands=['start']) #При комманде /start
def start(message):
    with open('data.json', 'r') as rdata:
        if rdata.read() == '':
            with open('data.json', 'w') as wdata:
                wdata.write('{}')
    bot.send_message(message.chat.id, 'Данный чат бот предоставлен в качестве проекта на IT-FEST-2022', reply_markup=base_markup)
    with open('data.json', 'r') as datar:
        data = json.loads(datar.read())
        try:
            user = data[str(message.chat.id)]
        except:
            with open('data.json', 'w') as data_write:
                data[str(message.chat.id)] = {'follows':[], 'viewed':[0], 'start_time':round(time.time())}
                data_write.write(json.dumps(data, indent=4, ensure_ascii=False))

@bot.message_handler(content_types=['text']) #Просмотр отправленного текста
def on_message(message):
    print(message.text)
    text = ''
    if message.text == 'Подписаться на события ❤️':
        btns = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btns.add(types.KeyboardButton('1️⃣ #TechnoCom'),
                 types.KeyboardButton('2️⃣ #ITfest_2022'),
                 types.KeyboardButton('3️⃣ #IASF2022'))
        btns.add(types.KeyboardButton('4️⃣ #ФестивальОКК'),
                 types.KeyboardButton('5️⃣ #Нейрофест'),
                 types.KeyboardButton('6️⃣ #НевидимыйМир'))
        btns.add(types.KeyboardButton('7️⃣ #КонкурсНИР'),
                 types.KeyboardButton('8️⃣ #VRARFest3D'),
                 types.KeyboardButton('Назад ↩️'))
        text = '1️⃣ Международный конкурс детских инженерных команд - <b>#TechnoCom</b>\n\n' \
               '2️⃣ Международный фестиваль информационных технологий «IT-фест» - <b>#ITfest_2022</b>\n\n' \
               '3️⃣ Международный аэрокосмический фестиваль - <b>#IASF2022</b>\n\n' \
               '4️⃣ Всероссийский фестиваль общекультурных компетенций - <b>#ФестивальОКК</b>\n\n' \
               '5️⃣ Всероссийский фестиваль нейротехнологий «Нейрофест» - <b>#Нейрофест</b>\n\n' \
               '6️⃣ Всероссийский конкурс по микробиологии «Невидимый мир» - <b>#НевидимыйМир</b>\n\n' \
               '7️⃣ Всероссийский конкурс научно-исследовательских работ - <b>#КонкурсНИР</b>\n\n' \
               '8️⃣ Международный фестиваль 3D-моделирования и программирования VRAR-Fest - <b>#VRARFest3D</b>'
        bot.send_message(message.chat.id, text=text, reply_markup=btns, parse_mode='html')

    #Отправка ссылок на группы
    elif message.text == '1️⃣ #TechnoCom':
        btns = types.InlineKeyboardMarkup()
        btns.add(types.InlineKeyboardButton(text='Подписаться', callback_data='f1'),
                 types.InlineKeyboardButton(text='Отписаться', callback_data='uf1'))
        text = 'Нажмите по кругу чтобы перейти в группу в ВКонтакте  →  [⚪️](https://vk.com/technocom2022)'
        bot.send_message(message.chat.id, text, parse_mode='Markdown', reply_markup=btns)
    elif message.text == '2️⃣ #ITfest_2022':
        btns = types.InlineKeyboardMarkup()
        btns.add(types.InlineKeyboardButton(text='Подписаться', callback_data='f2'),
                 types.InlineKeyboardButton(text='Отписаться', callback_data='uf2'))
        text = 'Нажмите по кругу чтобы перейти в группу в ВКонтакте  →  [⚪️](https://vk.com/itfest2022)'
        bot.send_message(message.chat.id, text, parse_mode='Markdown', reply_markup=btns)
    elif message.text == '3️⃣ #IASF2022':
        btns = types.InlineKeyboardMarkup()
        btns.add(types.InlineKeyboardButton(text='Подписаться', callback_data='f3'),
                 types.InlineKeyboardButton(text='Отписаться', callback_data='uf3'))
        text = 'Нажмите по кругу чтобы перейти в группу в ВКонтакте  →  [⚪️](https://vk.com/aerospaceproject)'
        bot.send_message(message.chat.id, text, parse_mode='Markdown', reply_markup=btns)
    elif message.text == '4️⃣ #ФестивальОКК':
        btns = types.InlineKeyboardMarkup()
        btns.add(types.InlineKeyboardButton(text='Подписаться', callback_data='f4'),
                 types.InlineKeyboardButton(text='Отписаться', callback_data='uf4'))
        text = 'Нажмите по кругу чтобы перейти в группу в ВКонтакте  →  [⚪️](https://vk.com/okk_fest)'
        bot.send_message(message.chat.id, text, parse_mode='Markdown', reply_markup=btns)
    elif message.text == '5️⃣ #Нейрофест':
        btns = types.InlineKeyboardMarkup()
        btns.add(types.InlineKeyboardButton(text='Подписаться', callback_data='f5'),
                 types.InlineKeyboardButton(text='Отписаться', callback_data='uf5'))
        text = 'Нажмите по кругу чтобы перейти в группу в ВКонтакте  →  [⚪️](https://vk.com/neurofest2022)'
        bot.send_message(message.chat.id, text, parse_mode='Markdown', reply_markup=btns)
    elif message.text == '6️⃣ #НевидимыйМир':
        btns = types.InlineKeyboardMarkup()
        btns.add(types.InlineKeyboardButton(text='Подписаться', callback_data='f6'),
                 types.InlineKeyboardButton(text='Отписаться', callback_data='uf6'))
        text = 'Нажмите по кругу чтобы перейти в группу в ВКонтакте  →  [⚪️](https://vk.com/nauchim.online)'
        bot.send_message(message.chat.id, text, parse_mode='Markdown', reply_markup=btns)
    elif message.text == '7️⃣ #КонкурсНИР':
        btns = types.InlineKeyboardMarkup()
        btns.add(types.InlineKeyboardButton(text='Подписаться', callback_data='f7'),
                 types.InlineKeyboardButton(text='Отписаться', callback_data='uf7'))
        text = 'Нажмите по кругу чтобы перейти в группу в ВКонтакте  →  [⚪️](https://vk.com/nauchim.online)'
        bot.send_message(message.chat.id, text, parse_mode='Markdown', reply_markup=btns)
    elif message.text == '8️⃣ #VRARFest3D':
        btns = types.InlineKeyboardMarkup()
        btns.add(types.InlineKeyboardButton(text='Подписаться', callback_data='f8'),
                 types.InlineKeyboardButton(text='Отписаться', callback_data='uf8'))
        text = 'Нажмите по кругу чтобы перейти в группу в ВКонтакте  →  [⚪️](https://vk.com/nauchim.online)'
        bot.send_message(message.chat.id, text, parse_mode='Markdown', reply_markup=btns)
    #реализация кнопки "назад"
    elif message.text == 'Назад ↩️':
        bot.send_message(message.chat.id, 'Стартовая страница 🔄', reply_markup=base_markup)
    #при нажатии просмотра постов
    elif message.text == 'Последние посты 📌':
        btns = types.ReplyKeyboardMarkup(resize_keyboard=True)

        btns.add(types.KeyboardButton('#TechnoCom'),
                 types.KeyboardButton('#ITfest_2022'))
        btns.add(types.KeyboardButton('#IASF2022'),
                 types.KeyboardButton('#ФестивальОКК'))
        btns.add(types.KeyboardButton('#Нейрофест'),
                 types.KeyboardButton('#НевидимыйМир'))
        btns.add(types.KeyboardButton('#КонкурсНИР'),
                 types.KeyboardButton('#VRARFest3D'))
        btns.add(types.KeyboardButton('Назад ↩️'))

        text = 'Международный конкурс детских инженерных команд - #TechnoCom\n' \
               'Международный фестиваль информационных технологий «IT-фест» - #ITfest_2022\n' \
               'Международный аэрокосмический фестиваль - #IASF2022\n' \
               'Всероссийский фестиваль общекультурных компетенций - #ФестивальОКК\n' \
               'Всероссийский фестиваль нейротехнологий «Нейрофест» - #Нейрофест\n' \
               'Всероссийский конкурс по микробиологии «Невидимый мир» - #НевидимыйМир\n' \
               'Всероссийский конкурс научно-исследовательских работ - #КонкурсНИР\n' \
               'Международный фестиваль 3D-моделирования и программирования VRAR-Fest - #VRARFest3D\n' \
               'Введите хештег:'
        msg = bot.send_message(message.chat.id, text, reply_markup=btns)
        bot.register_next_step_handler(msg, found)
    elif message.text == 'Новые посты на которые вы подписаны 🗞':
        with open('data.json', 'r') as rdata:
            data = json.loads(rdata.read())
        if data[str(message.chat.id)]['follows'] != []:
            for tag in data[str(message.chat.id)]['follows']:
                found(message, tag, True)
        else:
            bot.send_message(message.chat.id, 'Вы не подписаны ни на один хештег ❌')
    elif message.text == 'Контактные данные 📨':
        bot.send_message(message.chat.id, 'Привет! Если у вас возникли какие-либо вопросы, то вот наши контакты:\nГруппа ВКонтакте Научим.online https://vk.com/nauchim.online\nСайт с мероприятиями https://www.научим.online')
    elif message.text == 'Подписки 📝':
        with open('data.json', 'r') as rdata:
            data = json.loads(rdata.read())
        if data[str(message.chat.id)]['follows'] != []:
            text = '📝 Список подписок:'
            for tag in data[str(message.chat.id)]['follows']:
                text += f'\n{tag}'
            bot.send_message(message.chat.id, text)
        else:
            bot.send_message(message.chat.id, 'Вы не подписаны ни на один хештег 💔')


@bot.callback_query_handler(lambda call: len(call.data) > 0)
def call_back(call: types.CallbackQuery):
    with open('data.json', 'r') as rdata:
        data = json.loads(rdata.read())
        with open('data.json', 'w') as write_data:
            if list(call.data)[0] == 'f' and list(call.data)[1] in ['1', '2', '3', '4', '5', '6', '7', '8']:
                data[str(call.message.chat.id)]['follows'].append(tags[list(call.data)[1]])
                bot.answer_callback_query(call.id, f'Вы подписались на {tags[list(call.data)[1]]}')
                write_data.write(json.dumps(data, indent=4, ensure_ascii=False))
            elif list(call.data)[1] == 'f' and list(call.data)[0] == 'u' and list(call.data)[2] in ['1', '2', '3', '4', '5', '6', '7', '8']:
                try:
                    data[str(call.message.chat.id)]['follows'].pop(data[str(call.message.chat.id)]['follows'].index(''.join(tags[list(call.data)[2]])))
                    bot.answer_callback_query(call.id, f'Вы отписались от {tags[list(call.data)[2]]}')
                    write_data.write(json.dumps(data, indent=4, ensure_ascii=False))
                except:
                    bot.answer_callback_query(call.id, f'Вы не были подписаны на {tags[list(call.data)[2]]}')
                    write_data.write(json.dumps(data, indent=4, ensure_ascii=False))

def found(message, tag=None, only_new=False):
    if message.text == 'Назад ↩️':
        bot.send_message(message.chat.id, 'Стартовая страница 🔄', reply_markup=base_markup)
    else:
        id_ = 0
        i = 0
        founded = True
        if tag == None:
            bot.send_message(message.chat.id, 'Посик новостей... 🔎')
        else:
            bot.send_message(message.chat.id, f'Посик новостей по тегу {tag}... 🔎')
        if only_new == False:
            while not id_ in [-200248443, -210985709, -200248443, -196557207, -211803420, -211638918]:
                i += 1
                try:
                    if tag == None:
                        new = news_found(message.text, i)[i-1]
                    else:
                        new = news_found(tag, i)[i - 1]
                    id_ = new['owner_id']
                except:
                    founded = False
                    bot.send_message(message.chat.id, 'Не удалось найти постов за целый год! ❌', reply_markup=base_markup)
                    break
            if founded:
                post = new
                print(post)
                try:
                    text = post['text']
                except:
                    text = 'Без текста'
                images = []
                attachments = True
                try:
                    test = post['attachments']
                except:
                    attachments = False
                if attachments:
                    if post['attachments'] != []:
                        text += '\n\nФайлы и доп. ссылки:'
                        for attachment in post['attachments']:
                            try:
                                if attachment['type'] == 'link':
                                    text += f"\n{attachment['link']['url']}"
                                elif attachment['type'] == 'photo':
                                    response = rq.get(attachment['photo']['sizes'][-1]['url'])
                                    img = Image.open(BytesIO(response.content))
                                    images.append(img)
                                elif attachment['type'] == 'doc':
                                    url = f"{attachment['doc']['url']}"
                                    text += f'\n<a href="{url}">{attachment["doc"]["title"]}</a>'
                                elif attachment['type'] == 'video':
                                    url = f"https://vk.com/video{attachment['video']['owner_id']}_{attachment['video']['id']}"
                                    text += f'\n<a href="{url}">{attachment["video"]["title"]}</a>'
                            except:
                                pass
                with open('data.json', 'r') as rdata:
                    data = json.loads(rdata.read())
                if post['id'] not in data[str(message.chat.id)]['viewed']:
                    data[str(message.chat.id)]['viewed'].append(post['id'])
                    with open('data.json', 'w') as wdata:
                        wdata.write(json.dumps(data, indent=4, ensure_ascii=False))
                bot.send_message(message.chat.id, text, reply_markup=base_markup, parse_mode='html')
                if images != []:
                    for img in images:
                        bot.send_photo(message.chat.id, img)
        else:
            with open('data.json', 'r') as rdata:
                data = json.loads(rdata.read())
            for ii in range(10):
                new = {'id': 0}
                i = 0
                while not id_ in [-200248443, -210985709, -200248443, -196557207, -211803420, -211638918] or new['id'] in data[str(message.chat.id)]['viewed']:
                    i += 1
                    if i == 100:
                        break
                    try:
                        if tag == None:
                            new = news_found(message.text, i, data[str(message.chat.id)]['start_time'])[-1]
                        else:
                            new = news_found(tag, i, data[str(message.chat.id)]['start_time'])[-1]
                        id_ = new['owner_id']
                    except:
                        founded = False
                        if ii == 0:
                            bot.send_message(message.chat.id, f'Не удалось найти новых постов по тегу {tag} с момента первой комманды "/start" ❌', reply_markup=base_markup)
                        break
                if founded:
                    post = new
                    try:
                        text = post['text']
                    except:
                        text = 'Без текста'
                    images = []
                    attachments = True
                    try:
                        test = post['attachments']
                    except:
                        attachments = False
                    if attachments:
                        if post['attachments'] != []:
                            text += '\n\nФайлы и доп. ссылки:'
                            for attachment in post['attachments']:
                                try:
                                    if attachment['type'] == 'link':
                                        text += f"\n{attachment['link']['url']}"
                                    elif attachment['type'] == 'photo':
                                        response = rq.get(attachment['photo']['sizes'][-1]['url'])
                                        img = Image.open(BytesIO(response.content))
                                        images.append(img)
                                    elif attachment['type'] == 'doc':
                                        url = f"{attachment['doc']['url']}"
                                        text += f'\n<a href="{url}">{attachment["doc"]["title"]}</a>'
                                    elif attachment['type'] == 'video':
                                        url = f"https://vk.com/video{attachment['video']['owner_id']}_{attachment['video']['id']}"
                                        text += f'\n<a href="{url}">{attachment["video"]["title"]}</a>'
                                except:
                                    pass
                    with open('data.json', 'r') as rdata:
                        data = json.loads(rdata.read())
                    if post['id'] not in data[str(message.chat.id)]['viewed']:
                        data[str(message.chat.id)]['viewed'].append(post['id'])
                        with open('data.json', 'w') as wdata:
                            wdata.write(json.dumps(data, indent=4, ensure_ascii=False))
                    bot.send_message(message.chat.id, text, reply_markup=base_markup, parse_mode='html')
                    if images != []:
                        for img in images:
                            bot.send_photo(message.chat.id, img)
                else:
                    break


bot.infinity_polling()